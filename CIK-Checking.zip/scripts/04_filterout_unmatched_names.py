import requests
from pandas import ExcelWriter
import re
import os
import string
import pandas as pd
import numpy 


#####################
# Step I: read data
#####################

#User enters the file location information
#s = raw_input('Input the file location ->')
#s1 = raw_input("Input the original file name->")
#s2 = raw_input('Input the final output file name ->')
#sheet = raw_input('Input the save file name ->')
s="P:\Projects\Exhibit B\QC\EDGAR CIK Check\\2005"
s1="test.xlsx"
s2="output3.xlsx"

global NAME
NAME="o_issuer_name"

#For the main file path, one needs to make sure they are forward slashes
s = string.replace(s, "\\", '/')

# Combining the main folder location and the xlsx file that has the list of issuernames
main_location = s + '/' + s1
#main_location = "P:/PCAOB Staff/Interns/zhangy1/NAF/test/output_filter2.xlsx"


# Combining the temporary csv files for the different results with the folder location
results = s + '/' + s2
#results="P:/PCAOB Staff/Interns/zhangy1/NAF/test/output_final.xlsx"
	
		
#Pandas reading the excel, excel contain issuer, company and cik
in_file = pd.read_excel(main_location)
out_file = pd.read_excel(results)

# make merge variable consistent
in_file[NAME]=in_file[NAME].str.upper()
out_file[NAME]=out_file[NAME].str.upper()

#extract all in_files' columns names
in_names=list(in_file.columns)
in_names=[str(in_names[i]) for i in range(len(in_names))]

#left join merge in_file with out_file and filter out unmerged
merged= pd.merge(in_file,out_file,how="left",indicator=True)
merged=merged.reset_index()
left_only= merged.drop(merged[merged._merge!="left_only"].index)

#only keep in_files' columns
left_only1=left_only[in_names]

# write the result into excel	
writer = ExcelWriter(results)
out_file.to_excel(writer,"matched",index=False)
left_only1.to_excel(writer,'un_matched',index=False)
writer.save()








