import time
import requests
from bs4 import BeautifulSoup as bs
import pandas as pd
from pandas import ExcelWriter
import re
import os
import string


#####################
# Step I: read data
#####################
#data_path = raw_input('Input the data path ->')
#s1 = raw_input('Input the output folder ->')
#s2 = raw_input('Input the output file name ->')

data_path="P:\Projects\Exhibit B\QC\\EDGAR CIK Check"
s1="P:\Projects\Exhibit B\QC\EDGAR CIK Check\\all_check"
s2="input.xlsx"

global NAME
NAME="o_issuer_name"

results=s1 + "\\" +s2

years= range(2005,2017)  #that is 2005:2016
results_df = pd.DataFrame()

for year in years:
		path=data_path+'\\'+str(year)+'\\'+str(year) +str(".xlsx")
		in_file = pd.read_excel(path)
		results_df=results_df.append(in_file)
	
results_df=results_df.drop_duplicates(NAME,keep="first")
	
# write the result into excel	
writer = ExcelWriter(results)
results_df.to_excel(writer,index=False)
writer.save()