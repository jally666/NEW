# author: Joon-Suk Lee

import pandas as pd
import glob

root_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Scripts'
temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\NAF_Noah\temp'
output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
output_path=r'P:\PCAOB Staff\Interns\zhangy1\NAF_Noah\temp'

i=0
for file in glob.glob(temp_path+'\\*.csv'):
    if '~' not in file:
        if i==0:
            df=pd.read_csv(file, encoding='latin1')
            i=i+1
        else:
            df2=pd.read_csv(file, encoding='latin1')
            df=pd.concat([df,df2])
            i=i+1
df=df.reset_index()
del df['index']
df.to_csv(output_path+'\\Exh C 2015-2016.csv', encoding='latin1', index=False)

#EOF
