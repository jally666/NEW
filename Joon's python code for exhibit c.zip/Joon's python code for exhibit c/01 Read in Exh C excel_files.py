# author: Joon-Suk Lee

import os
import fnmatch
import pandas as pd
import win32com.client
import re

root_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Scripts'
temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\NAF_Noah\temp'
output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
data_path=r'P:\Data\PCAOBdata\data\exhibit_c'

years= [2015, 2016]

for year in years:
    path=data_path+'\\'+str(year)
    files_list = [os.path.join(dirpath, f) for dirpath, dirnames, fi in os.walk(path) for f in fnmatch.filter(fi, '*.*xls*')] # recursively go through all Excel files in folder and its subfolders
    for file in files_list:
        filename=file.replace(path+'\\','')
        if '\\' in filename:
            filename=re.sub(r'[A-Z]+\\','',filename)
        xl=win32com.client.Dispatch("Excel.Application") # convert Excel sheets to CSV b/c pd.read_excel sometimes creates errors
        #xl.Visible=True
        xl.DisplayAlerts = False
        wb=xl.Workbooks.Open(file)
        sh=xl.Sheets[0]
        # sh.Select()
        sh.SaveAs(temp_path+'\\Raw\\'+ filename +'.csv', 23)
        wb.Close()
        df=pd.read_csv(temp_path+'\\Raw\\'+ filename +'.csv', encoding='latin1') # important to specify encoding (should be cp1252 or latin) in order to avoid incorrect reading-in (i.e. Python may believe a file is encoded UTF-8, which then causes issues when saving file later with "to_csv")
        df['unnamed:0']=df.index # first column of csv is read in as index - here it is copied into a standard column
        df=df.reset_index()
        del df['index']
        df=df.fillna('')
        # rename all columns to varXX format where XX is number of columns
        new_varnames=['var'+str(x) for x in range(0,len(df.columns))]
        rename_dict=dict((df.columns[j], new_varnames[j]) for j in range(0,len(df.columns)))
        df=df.rename(columns=rename_dict)
        df_t=df.transpose()
        '''
        # Find firm name, first method
        c=0
        found_item=False
        while c < len(df_t.columns) and found_item==False:
            found=df_t.ix[df_t[c].str.contains('Firm Name',na=False),c]
            if len(found)>0:
                found_item=True
            c=c+1
        if found_item==True:
            firm_name=found[0].replace('Firm Name:','').strip()
        # Find firm name, second method:
        if found_item==False:
            c=0
            while c < len(df_t.columns) and found_item==False:
                found=df_t.ix[df_t[c].str.contains('Issuer Information',na=False),c]
                if len(found)>0:
                    found_item=True
                c=c+1
            firm_name=df_t.ix[found.index[0],c]
        '''
        firm_name=filename
		c=0
		found_item=False
		while c < len(df_t.columns) and found_item==False:
			found=df_t.ix[df_t[c].str.contains('Opinion of another auditor',na=False),c] #Search for the column that contains the phrase 'Opinion of other auditor' which indicates the row (in the untransposed file) where the headers are; ignore cells with "nan"/blank value
			if len(found)>0:
				found_item=True
			c=c+1
		if found_item==True:
			header_row=c-1
			v_oa_opinion=found.index[0]
			# locate the column locations for the columns of interest
			found=df_t.ix[df_t[header_row].str.contains('Work of another auditor',na=False),header_row]
			v_oa_work=found.index[0]
					
			found=df_t.ix[df_t[header_row].str.contains('REVENUE for most recent year reported on by the firm',na=False),header_row]
			v_oa_perc_rev=found.index[0]        
			found=df_t.ix[df_t[header_row].str.contains('ASSETS for most recent year reported on by the firm',na=False),header_row]
			v_oa_perc_assets=found.index[0]
			found=df_t.ix[df_t[header_row].str.contains('List countries of affiliated or other firms',na=False),header_row]
			v_oa_countries=found.index[0]
			found=df_t.ix[df_t[header_row].str.contains('Indicate % of consolidated assets',na=False),header_row]
			v_oa_cons_assets=found.index[0]        
			found=df_t.ix[df_t[header_row].str.contains('Indicate % of consolidated revenue',na=False),header_row]
			v_oa_cons_rev=found.index[0]
			found=df_t.ix[df_t[header_row].str.contains('Central Indexing Key',na=False),header_row]
			v_cik=found.index[0]
			found=df_t.ix[df_t[header_row].str.contains('Issuer name',na=False),header_row]        
			v_issuer_name=found.index[0]
					
            # reformat dataset to start with header row and limit to the columns of interests
			df=df[header_row+1:]
			df=df[[v_cik, v_issuer_name,v_oa_opinion, v_oa_work, v_oa_perc_rev,v_oa_perc_assets, v_oa_cons_assets, v_oa_cons_rev, v_oa_countries]]
			df=df.drop(df[(df[v_issuer_name]!='') & (df[v_cik]=='')].index)
			df['source']=file
			df['firm_name']=firm_name
			df['year']=year
			# rename variables/headers
			varlist=[v_cik, v_issuer_name,v_oa_opinion, v_oa_work, v_oa_perc_rev,v_oa_perc_assets, v_oa_cons_assets, v_oa_cons_rev, v_oa_countries]
			varnames=['cik', 'issuer_name','oa_opinion', 'oa_work', 'oa_perc_rev','oa_perc_assets', 'oa_cons_assets', 'oa_cons_rev', 'oa_countries']
			rename_dict=dict((varlist[j], varnames[j]) for j in range(0,len(varlist)))
			df=df.rename(columns=rename_dict)
						
            df.to_csv(temp_path+'\\'+ str(firm_name) +'.csv', encoding='latin1', index=False)
        else:
            df=pd.DataFrame(['Not regular'],columns=['var0'])
            df.to_csv(temp_path+'\\~'+ str(firm_name) +'.csv', encoding='latin1', index=False)
#EOF
