# author: Joon-Suk Lee

import pandas as pd

root_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Scripts'
temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\NAF_Noah\temp'
output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
output_path=r'P:\PCAOB Staff\Interns\zhangy1\NAF_Noah\temp'


df=pd.read_csv(output_path+'\\Exh C 2015-2016.csv', encoding='latin1')

# Standardize answers
df.ix[df['oa_opinion'].str.lower().str.contains('yes',na=False),'oa_opinion']='yes'
df.ix[df['oa_opinion'].str.lower().str.contains('no',na=False),'oa_opinion']='no'
df.ix[df['oa_work'].str.lower().str.contains('no',na=False),'oa_work']='no'
df.ix[df['oa_work'].str.lower().str.contains('yes',na=False),'oa_work']='yes'

# convert Year and CIK to string
df['year']=df['year'].astype(str,raise_on_error=False)
df['cik']=df['cik'].astype(str,raise_on_error=False)
df['year']=df['year'].str.replace('\.0','')
df['cik']=df['cik'].str.replace('\.0','')

# Replace all NaN value with empty strings
for i in df.columns:
    df[i]=df[i].replace(float('NaN'),'')

# Remove empty rows
df['temp']=''
for j in range(0,len(df.columns)): # concatenate all relevant rows
    if j not in [1,10,11,12,13]:
        df['temp']=df['temp']+df[df.columns[j]].astype(str,raise_on_error=False)
df['temp']=df['temp'].str.strip()
df=df[df['temp']!='']
del df['temp']
df=df.reset_index()
del df['index']

# drop extraneous observations (no proper CIK and no answer to OA questions)
df=df.drop(df[(df['cik'].str.contains('[a-zA-z]')) & (df['oa_work']!='no') & (df['oa_work']!='yes') & (df['oa_opinion']!='no') & (df['oa_opinion']!='yes')].index)
df=df.reset_index()
del df['index']

# Repeat CIK information for all rows pertaining to a particular engagement
for i in range(0,len(df['cik'])):
    if (df['cik'][i]==''):
        df['cik'][i]=df['cik'][i-1]

# Clean up numeric values:
for k in ['oa_cons_assets','oa_cons_rev','oa_perc_assets','oa_perc_rev']:
    df[k]=df[k].str.replace('%',' ')
    df[k]=df[k].str.replace(',',' ')
    df[k]=df[k].str.replace(r'\r\r\n',' ')
    df[k]=df[k].str.replace(r'\r','')
    df[k]=df[k].str.replace(r'-','') #some entries show negative percent values; some entries have "-" to mark different other auditors
    df[k]=df[k].str.replace('[a-zA-Z_</\(\)]+','')
    df.ix[df[k]=='  .',k]=''

# Sum up percentage values if multiple values entered into same row
for k in ['oa_cons_assets','oa_cons_rev','oa_perc_assets','oa_perc_rev']:
    d=[x.split(' ') for x in df[k]]
    d=[[x if ((x!='')& (x!='..')) else '0' for x in y ] for y in d]
    d=[[float(x) for x in y] for y in d]
    d=[sum(x) for x in d]
    df['temp']=d
    del df[k]
    df[k]=df['temp']
    del df['temp']

for k in ['oa_cons_assets','oa_cons_rev','oa_perc_assets','oa_perc_rev']:    
    # Sum up percentage values if multiple rows of values for same engagement
    dfx=df.groupby(['year','cik','source'])[k].sum()
    dfx=pd.DataFrame(dfx)
    dfx=dfx.reset_index()
    del df[k]
    # merge on summed up percentage values
    df=pd.merge(df,dfx,how='outer',left_on=['year','cik','source'],right_on=['year','cik','source'])
    
# only retain one line per engagement
df=df.drop(df[((df['oa_work']=='') | (df['oa_opinion']=='')) & (df['issuer_name']=='')].index)
df=df.drop(df[(df['issuer_name']=='')].index) # remove additional rows for Vale S.A. and Centrais Eletricas Brasileiras S.A.
df=df.reset_index()
del df['index']
del df['oa_countries']

# create  standardized rev%, assets% variables:
# use oa_perc unless oa_perc==0 and oa_cons>0
df['std_oa_perc_rev']=df['oa_perc_rev']
df['std_oa_perc_assets']=df['oa_perc_assets']
for i in range(0,len(df['std_oa_perc_rev'])):
    if (df['oa_perc_rev'][i]==0) & (df['oa_cons_rev'][i]>0):
        df['std_oa_perc_rev'][i]=df['oa_cons_rev'][i]
for i in range(0,len(df['std_oa_perc_assets'])):
    if (df['oa_perc_assets'][i]==0) & (df['oa_cons_assets'][i]>0):
        df['std_oa_perc_assets'][i]=df['oa_cons_assets'][i]

# check for cases where (standardized) % values close to 100%, possibly above 100%
df['f_unusual_perc']=0
df.ix[df[((df['std_oa_perc_rev']>90)|(df['std_oa_perc_assets']>90))].index,'f_unusual_perc']=1
    
df.to_csv(output_path+'\\Exh C 2015-2016 processed.csv', index=False, encoding='latin1')

# "Collapse" (i.e. sum "yes"/"no" answers given for Other Auditors-related questions)    
df['count']=1
df2=df.groupby(['year','oa_opinion'])['count'].sum()
df2=df2.reset_index()
df3=df.groupby(['year','oa_work'])['count'].sum()
df3=df3.reset_index()
del df['count']
df2.to_csv(output_path+'\\Exh C 2015-2016 oa_opinion count.csv', index=False, encoding='latin1')
df3.to_csv(output_path+'\\Exh C 2015-2016 oa_work count.csv', index=False, encoding='latin1')
# create variable oa_used = oa_opinion | oa_work
df['oa_used']='no'
df.ix[df[((df['oa_work']=='yes')|(df['oa_opinion']=='yes'))].index,'oa_used']='yes'
# change oa_used = 'yes' if any of the % values > 0
df.ix[df[((df['std_oa_perc_rev']>0)|(df['std_oa_perc_assets']>0))].index,'oa_used']='yes'
df['count']=1
df4=df.groupby(['year','oa_used'])['count'].sum()
df4=df4.reset_index()
del df['count']
df4.to_csv(output_path+'\\Exh C 2015-2016 oa_used count.csv', index=False, encoding='latin1')


#EOF
