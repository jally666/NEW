# author:Yichen Joon-Suk Lee
# Date: 8/10/2017

import pandas as pd

#temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\temp'
#output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
output_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\output'

df=pd.read_csv(output_path+'\\Exh C 2010-2016.csv', encoding='latin1')

# Remove empty rows
df.fillna("",inplace=True)
df=df.reset_index()
df=df.drop(df[(df["Parent_company_issuer_name"]=="") & (df["City"]=="")&(df["Parent_CIK"]=="")].index)
df= df.drop(df[(df["Parent_company_issuer_name"]=='') & (df["subsidiary_or_component_name"]=='')].index)
# convert Year and CIK to string
df['Parent_CIK']=df['Parent_CIK'].astype(str,raise_on_error=False)
df['Parent_CIK']=df['Parent_CIK'].str.replace('\.0','')

#clean country
df["Country_other_firms"]=df['Country_other_firms'].str.upper()
df["Country_other_firms"]=df['Country_other_firms'].str.replace('NONE','')
df["Country_other_firms"]=df['Country_other_firms'].str.replace('N/A','')


df.to_csv(output_path+'\\Exh C 2010-2016 cleaned.csv', index=False, encoding='latin1')


#EOF
