
# author:Yichen Joon-Suk Lee
# Date: 8/10/2017

import pandas as pd
import glob

#temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\temp'
#output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
output_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\output'

i=0
for file in glob.glob(temp_path+'\\*.csv'):
    if '~' not in file:
        if i==0:
            df=pd.read_csv(file, encoding='latin1')
            i=i+1
        else:
            df2=pd.read_csv(file, encoding='latin1')
            df=pd.concat([df,df2])
            i=i+1
df=df.reset_index()
del df['index']
df.to_csv(output_path+'\\Exh C 2010-2016.csv', encoding='latin1', index=False)

#EOF

































