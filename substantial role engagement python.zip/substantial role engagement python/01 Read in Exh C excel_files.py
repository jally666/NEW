# author:Yichen Joon-Suk Lee
# Date: 8/10/2017
##########Cautions################
#1.  Be careful, build a subfolder "Raw" in your temp_path directory
#2.  close all your excels, because win32com maybe wrong sometimes
#################################

import os
import fnmatch
import pandas as pd
import win32com.client
import re
import numpy

#####you can change the directory here##########
#temp_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Temp'
temp_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\temp'
#output_path=r'O:\Data and analyses\2017.05.24 Exhibit C processing\Output'
output_path=r'P:\PCAOB Staff\Interns\zhangy1\Exhibit C_Noah\output'
data_path=r'P:\Data\PCAOBdata\data\exhibit_c'

years= range(2010,2017)

wrong_list=[]

for year in years:
    path=data_path+'\\'+str(year)
	# recursively go through all Excel files in folder and its subfolders
    files_list = [os.path.join(dirpath, f) for dirpath, dirnames, fi in os.walk(path) for f in fnmatch.filter(fi, '*.*xls*')] 
    for file in files_list:
		try:
			
			# Part I: save substantial engagment sheet as csv
			filename=file.replace(path+'\\','')
			if '\\' in filename:
				filename=re.sub(r'[A-Z]+\\','',filename)
			
			xl=win32com.client.Dispatch("Excel.Application")  # convert Excel sheets to CSV b/c pd.read_excel sometimes creates errors
			#xl.Visible=True
			xl.DisplayAlerts = False   #here could be error sometimes, I maybe garbage here, so close all your excels
			wb=xl.Workbooks.Open(file)
			### Number of Sheets 
			sheetnum = wb.Sheets.Count
			t=numpy.nan
			for x in range(0, sheetnum):
				if re.findall("(Substantial)|(substantial)|(Sub)", wb.Sheets[x].name):
					t=x
					break	
			sh=xl.Sheets[t]  #this is to choose second sheet
			# sh.Select()
			sh.SaveAs(temp_path+'\\Raw\\'+ filename +'.csv', 23)
			wb.Close()
			
			#Part II: read each csv and tranpose data to find our target data
			
			df=pd.read_csv(temp_path+'\\Raw\\'+ filename +'.csv', encoding='latin1') # important to specify encoding (should be cp1252 or latin) in order to avoid incorrect reading-in (i.e. Python may believe a file is encoded UTF-8, which then causes issues when saving file later with "to_csv")
			
			df['unnamed:0']=df.index # first column of csv is read in as index - here it is copied into a standard column
			df=df.reset_index()
			del df['index']
			df=df.fillna('')
			# rename all columns to varXX format where XX is number of columns
			new_varnames=['var'+str(x) for x in range(0,len(df.columns))]
			rename_dict=dict((df.columns[j], new_varnames[j]) for j in range(0,len(df.columns)))
			df=df.rename(columns=rename_dict)
			df_t=df.transpose()

			firm_name=filename
			c=0
			found_item=False
			while c < len(df_t.columns) and found_item==False:
				found=df_t.ix[df_t[c].str.contains('Parent company issuer name',na=False),c] #Search for the column that contains the phrase 'Opinion of other auditor' which indicates the row (in the untransposed file) where the headers are; ignore cells with "nan"/blank value
				if len(found)>0:
					found_item=True
				c=c+1
			if found_item==True:
				header_row=c-1
				# locate the column locations for the columns of interest
				found=df_t.ix[df_t[header_row].str.contains('Parent company issuer name',na=False),header_row]
				prt_cpn_name=found.index[0]
				found=df_t.ix[df_t[header_row].str.contains('Name of subsidiary or component',na=False),header_row]
				sub_name=found.index[0]        
				found=df_t.ix[df_t[header_row].str.contains('City',na=False),header_row]
				cpn_city=found.index[0]
				found=df_t.ix[df_t[header_row].str.contains('(Parent Issuer Central Indexing Key)|(CIK)|(cik)',na=False),header_row]
				prt_cik=found.index[0]
				found=df_t.ix[df_t[header_row].str.contains('List countries of affiliated or other firms',na=False),header_row]
				cnty_otherfirm=found.index[0]
		
				# reformat dataset to start with header row and limit to the columns of interests
				df=df[header_row+1:]
				df=df[[prt_cpn_name, sub_name,cpn_city, prt_cik,cnty_otherfirm]]
				df=df.reset_index(drop=True)  #here is importent, otherwise it will turn "level_0" already exist
				df=df.drop(df[(df[sub_name]=='') & (df[prt_cik]=='') & (df[cpn_city]=="")].index)
				df=df.reset_index(drop=True)
				df=df.drop(df[(df[prt_cpn_name]=='') & (df[prt_cik]=='')& (df[cpn_city]=="")].index)
				df=df.reset_index(drop=True)
				df = df.fillna(method='ffill', axis=0) 
				df['source']=file
				df['firm_name']=firm_name
				df['year']=year
				# rename variables/headers
				varlist=[prt_cpn_name, sub_name,cpn_city, prt_cik,cnty_otherfirm]
				varnames=['Parent_company_issuer_name', 'subsidiary_or_component_name','City', 'Parent_CIK',"Country_other_firms"]
				rename_dict=dict((varlist[j], varnames[j]) for j in range(0,len(varlist)))
				df=df.rename(columns=rename_dict)
							
				df.to_csv(temp_path+'\\'+ str(firm_name) +'.csv', encoding='latin1', index=False)
			else:
				df=pd.DataFrame(['Not regular'],columns=['var0'])
				df.to_csv(temp_path+'\\~'+ str(firm_name) +'.csv', encoding='latin1', index=False)
		except:
			print file
			wrong_list.append(file)
			pass

wrong_df=pd.DataFrame(wrong_list)	
wrong_df.to_csv(output_path+'\\wrong files.csv', encoding='latin1', index=False)		
#EOF
