#library
library(neuralnet)
library(ROCR)
library(PRROC)
library(pROC)
library(AUC)
#import data
data<-read.csv("P:/Projects/Risk Modeling Tools/2017/Q1/mergedrestfinal.csv",header=TRUE)
#subset
var_names <- c("RevRec", "BigR", "restatea", "restateall", "CIK", "Year", "Qtr", "Sector", "Testing", "AT", 
              "SALE", "AQA", "RECD", "Rectr", "DRC", "RECUB", "INVFG", "GDWL", "INVT", "INTAN", "DLTT", "LCT",
              "GBL_MKTCAP_M", "SHORTINT", "CSHO", "COGS", "ACT", "PPENT", "DP", "XSGA", "CH", "TXP")
final=subset(data, select=var_names)
final$Testing[is.na(final$Testing)] <- 0
#drop missing
final <- subset(final, !is.na(CIK))
final <- subset(final, !is.na(Year))
final <- final[complete.cases(final[,1:(dim(final))[2]]),]
#sector specific 
financials <- final[which(final$Sector=="Financials"),]
nonfinancials <- final[which(final$Sector!="Financials"),]

#nn formula -- BigR, RevRec
f1 <- as.formula(paste("BigR ~ AT + SALE + AQA + RECD + Rectr + DRC + RECUB + INVFG + GDWL + INVT + INTAN + DLTT + LCT + GBL_MKTCAP_M + SHORTINT + CSHO + COGS + ACT + PPENT + DP + XSGA + CH + TXP"))
f2 <- as.formula(paste("RevRec ~ AT + SALE + AQA + RECD + Rectr + DRC + RECUB + INVFG + GDWL + INVT + INTAN + DLTT + LCT + GBL_MKTCAP_M + SHORTINT + CSHO + COGS + ACT + PPENT + DP + XSGA + CH + TXP"))
#financials
#train nn -- BigR
set.seed(1)
library(neuralnet)
nn <- neuralnet(f1, data = financials[which(financials$Year%in%2009:2013),], hidden = 6, linear.output = F, threshold = 0.075)
print(nn$result.matrix)
nn.pred <- compute(nn, financials[which(financials$Year==2014),10:((dim(financials))[2])])
#plot ROC
detach(package:neuralnet,unload = T)
pred <- prediction(nn.pred$net.result, financials[which(financials$Year==2014),2])
pref <- performance(pred, "tpr", "fpr")
plot(pref, lwd = 2, col="blue", main = "ROC")
abline(a=0, b=1)
#AUC value
auc <- cbind(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2]))
pr.curve(auc[which(auc[,2]==1),1],auc[which(auc[,2]==0),1],curve = TRUE)


#####################################################
#####################################################
#Multiple Try
#Naive Model - hidden = 1
set.seed(1)
library(neuralnet)
nn <- neuralnet(f1, data = financials[which(financials$Year%in%2009:2013),], hidden = 1, linear.output = F)
print(nn$result.matrix)
nn.pred <- compute(nn, financials[which(financials$Year==2014),10:((dim(financials))[2])])
#plot ROC
detach(package:neuralnet,unload = T)
pred1 <- prediction(nn.pred$net.result, financials[which(financials$Year==2014),2])
pref1 <- performance(pred1, "tpr", "fpr")
plot(pref1, lwd = 2, col="blue", main = "ROC")
abline(a=0, b=1)
#AUC value
z1 <- auc(roc(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2])))
#auc1 <- cbind(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2]))
#pr.curve(auc1[which(auc1[,2]==1),1],auc1[which(auc1[,2]==0),1],curve = TRUE)

#Multiple Try
#hidden = 6
set.seed(1)
library(neuralnet)
nn <- neuralnet(f1, data = financials[which(financials$Year%in%2009:2013),], hidden = 6, linear.output = F, threshold = 0.075)
print(nn$result.matrix)
nn.pred <- compute(nn, financials[which(financials$Year==2014),10:((dim(financials))[2])])
#plot ROC
detach(package:neuralnet,unload = T)
pred2 <- prediction(nn.pred$net.result, financials[which(financials$Year==2014),2])
pref2 <- performance(pred2, "tpr", "fpr")
plot(pref2, lwd = 2, col="blue", main = "ROC")
abline(a=0, b=1)
#AUC value
z2 <- auc(roc(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2])))
#auc2 <- cbind(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2]))
#pr.curve(auc2[which(auc2[,2]==1),1],auc2[which(auc2[,2]==0),1],curve = TRUE)

#Multiple Try
#hidden = 12
set.seed(1)
library(neuralnet)
nn <- neuralnet(f1, data = financials[which(financials$Year%in%2009:2013),], hidden = 12, linear.output = F, threshold = 0.085)
print(nn$result.matrix)
nn.pred <- compute(nn, financials[which(financials$Year==2014),10:((dim(financials))[2])])
#plot ROC
detach(package:neuralnet,unload = T)
pred3 <- prediction(nn.pred$net.result, financials[which(financials$Year==2014),2])
pref3 <- performance(pred3, "tpr", "fpr")
plot(pref3, lwd = 2, col="blue", main = "ROC")
abline(a=0, b=1)
#AUC value
z3 <- auc(roc(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2])))
#auc3 <- cbind(nn.pred$net.result,as.numeric(financials[which(financials$Year==2014),2]))
#pr.curve(auc3[which(auc3[,2]==1),1],auc3[which(auc3[,2]==0),1],curve = TRUE)
#####################################################
#####################################################

#plot multiple
plot(pref1, ylim=c(0, 1), col=1, main="BigR")
plot(pref2, ylim=c(0, 1), add=TRUE, col=2)
plot(pref3, ylim=c(0,1), add=TRUE, col=3)
legend("topleft",col= c(1,2,3), lty=1:1, c("Naive Model", "Hidden = 6", "Hidden = 12"))


