

# This program runs a random forest that trains on 2009-2014 data and predicts for 2016 Q4 data. Annual, quarterly, and difference 
# RAW variables are included. This program also attaches the BigR and RevRec scores to the list of issuers sent to CEA 
# by ORA for 2016 Q4.



####################################
#Set up data
####################################


# Update 
setwd("P:/Projects/Risk Modeling Tools/2017/Q1")

library(randomForest)
library(pROC)
library(ROCR)

data<-read.csv("mergedrestfinal.csv",header=TRUE)

# To choose variables

var_names = c("RevRec", "BigR", "restatea", "restateall", "CIK", "Year", "Qtr", "Sector", "Testing", "AT", "SALE", 
            "AQA", "RECD", "Rectr", "DRC", "RECUB", "INVFG", "GDWL", "INVT", "INTAN", "DLTT", "LCT", "GBL_MKTCAP_M", "SHORTINT", 
            "CSHO", "COGS", "ACT", "PPENT", "DP", "XSGA", "CH", "TXP")

final=subset(data, select=var_names)
final$Testing[is.na(final$Testing)]<-0
final<-subset(final, !is.na(CIK))
final<-subset(final, !is.na(Year))

# Drop whenever we have NA's
final<-final[complete.cases(final[,1:(dim(final))[2]]),]

# Creating vectors to specify RF regression rather than classifiers
final$restateall=as.factor(final$restateall)
final$restatea=as.factor(final$restatea)
final$BigR=as.factor(final$BigR)
final$RevRec=as.factor(final$RevRec)
final$CIK=as.numeric(as.character(final$CIK))


#Create sector-specific datasets
financials<-final[which(final$Sector=="Financials"),]
nonfinancials<-final[which(final$Sector!="Financials"),]


##################################
# NON FINANCIALS  - CHANGE ALL "FINAL" TO nonfinancials
##################################

##################################
##################################
# BigR
##################################
##################################

# Build with 2009 to 2014 data
# columns # to # are predictors. Second column # is the Y 
fit <- randomForest(nonfinancials[which(nonfinancials$Year%in%2009:2014), 10:((dim(nonfinancials))[2])], nonfinancials[which(nonfinancials$Year%in%2009:2014),2], importance=FALSE,ntree=5000)
# Predict 2017
pred1=predict(fit,nonfinancials[which(nonfinancials$Year==2017 & nonfinancials$Qtr==1 & nonfinancials$Testing==1),10:((dim(nonfinancials))[2])],type="prob")
# Output
table_output <- cbind(nonfinancials$CIK[which(nonfinancials$Year==2017 & nonfinancials$Qtr==1 & nonfinancials$Testing==1)], pred1)
#write.csv(table_output, file = "P:/Projects/Risk Modeling Tools/2017/Q1/BigR.csv")


##################################
##################################
# RevRec
##################################
##################################

# Build with 2009 to 2014 data
# columns # to # are predictors. Second column # is the Y 
fit <- randomForest(nonfinancials[which(nonfinancials$Year%in%2009:2014),10:((dim(nonfinancials))[2])],nonfinancials[which(nonfinancials$Year%in%2009:2014),1], importance=FALSE,ntree=5000)
# Predict 2017
pred2=predict(fit,nonfinancials[which(nonfinancials$Year==2017 & nonfinancials$Qtr==1 & nonfinancials$Testing==1),10:((dim(nonfinancials))[2])],type="prob")
# Output
table_output <- cbind(nonfinancials$CIK[which(nonfinancials$Year==2017 & nonfinancials$Qtr==1 & nonfinancials$Testing==1)], pred2)
#write.csv(table_output, file = "P:/Projects/Risk Modeling Tools/2017/Q1/RevRec.csv")

#############################

##################################
# FINANCIALS  - CHANGE ALL "FINAL" TO financials
##################################



##################################
##################################
# FinBigR
##################################
##################################

# Build with 2009 to 2014 data
# columns # to # are predictors. Second column # is the Y 
fit <- randomForest(financials[which(financials$Year%in%2009:2014), 10:((dim(financials))[2])],financials[which(financials$Year%in%2009:2014),2], importance=FALSE,ntree=5000)
# Predict 2017
pred3=predict(fit,financials[which(financials$Year==2017 & financials$Qtr==1 & financials$Testing==1),10:((dim(financials))[2])],type="prob")
# Output
table_output <- cbind(financials$CIK[which(financials$Year==2017 & financials$Qtr== 1 & financials$Testing==1)], pred3)
#write.csv(table_output, file = "P:/Projects/Risk Modeling Tools/2017/Q1/FinBigR.csv")



##################################
##################################
# FinRevRec
##################################
##################################

# Build with 2009 to 2014 data
# columns # to # are predictors. Second column # is the Y 
fit <- randomForest(financials[which(financials$Year%in%2009:2014),10:((dim(financials))[2])],financials[which(financials$Year%in%2009:2014),1], importance=FALSE,ntree=5000)
# Predict 2017
pred4=predict(fit,financials[which(financials$Year==2017 & financials$Qtr==1 & financials$Testing==1),10:((dim(financials))[2])],type="prob")
# Output
table_output <- cbind(financials$CIK[which(financials$Year==2017 & financials$Qtr==1 & financials$Testing==1)], pred4)
#write.csv(table_output, file = "P:/Projects/Risk Modeling Tools/2017/Q1/FinRevRec.csv")


##################################
#Create output for ORA
##################################

#Insheet Issuers
issuers<-read.csv("P:/Projects/Risk Modeling Tools/2016/Q4/IRA Population 2016Q4_NoFormula.csv",header=TRUE)
var_names<-c("CIK", "Company")
issuers<-subset(issuers, select=var_names)
issuers<-na.omit(issuers)

#Merge BigR with issuers
BigR<-read.csv("P:/Projects/Risk Modeling Tools/2016/Q4/Predictions/BigR.csv", header=TRUE)
BigR<-na.omit(BigR)
colnames(BigR)<-c("Obs", "CIK", "score_no", "ScoreBigR")
BigR$ScoreBigR=BigR$ScoreBigR*100

varnames=c("CIK", "ScoreBigR")
BigR<-subset(BigR, select=varnames)
BigR<-unique(BigR)
issuers_merged1<-merge(issuers, BigR, by="CIK", all=FALSE)
issuers_merged1<-unique(issuers_merged1)
issuers_merged1<- issuers_merged1[with(issuers_merged1, order(-ScoreBigR)), ]
issuers_merged1$RankBigR<-1:nrow(issuers_merged1)


#Merge RevRec with issuers
RevRec<-read.csv("P:/Projects/Risk Modeling Tools/2016/Q4/Predictions/RevRec.csv", header=FALSE)
RevRec<-na.omit(RevRec)
colnames(RevRec)<-c("Obs", "CIK", "score_no", "ScoreRevRec")
RevRec$ScoreRevRec=RevRec$ScoreRevRec*100

varnames=c("CIK", "ScoreRevRec")
RevRec<-subset(RevRec, select=varnames)
RevRec<-unique(RevRec)
issuers_merged2<-merge(issuers_merged1, RevRec, by="CIK", all=FALSE)
issuers_merged2<-unique(issuers_merged2)
issuers_merged2<- issuers_merged2[with(issuers_merged2, order(-ScoreRevRec)), ]
issuers_merged2$RankRevRec<-1:nrow(issuers_merged2)


#Write final csv file
issuers_merged<- issuers_merged2[with(issuers_merged2, order(CIK)),]
write.csv(issuers_merged, file = "P:/Projects/Risk Modeling Tools/2016/Q4/Predictions/2016Q4_Predictions.csv", row.names = FALSE)
write.csv(issuers_merged, file = "P:/Projects/Risk Modeling Tools/2016/Q4/Deliverable/2016Q4_Predictions.csv", row.names = FALSE)

