
library(MASS) 
library(nor1mix)
library(compiler)

set.seed(1)

obs <- 2000


# Error terms. I think we're using 1, 4, and 6. Might also try 3
distribution <- 6  # Use 1 for normal
                   #     2 for t-dist with 3 df
                   #     3 for bivariate chi squared with 1 degree of freedom
                   #     4 for bivariate beta distribution with a= ,b=
                   #     5 for bivariate mixture of normals
                   #     6 for "problematic" distribution

rho = .9  # use .5 and .9
sigma_sq = 1
varcovar <- matrix(c(sigma_sq,(sigma_sq^.5)*rho,(sigma_sq^.5)*rho, 1), nrow = 2, ncol = 2)
##############################################################################################
# Begining of function definitions
draw.errors <- function(code) {
  errors <- matrix(rep(NA,(obs*2)),nrow=obs,ncol=2)
  for(i in 1:obs){
     if(code==1){
        errors[i,] <- mvrnorm(1, rep(0,2), varcovar)
     }else if(code==2){
        errors[i,] <- rmvt(1, sigma=varcovar,df = 3) 
     }else if(code==3){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind((qchisq(u_error[1],df=1)-qchisq(.5,df=1)),(qchisq(u_error[2],df=1)-qchisq(.5,df=1)))
     }else if(code==4){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind((10*qbeta(u_error[1],.5,.5)-5),(10*qbeta(u_error[2],.5,.5)-5))
     }else if(code==5){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind(qnorMix(u_error[1],ex),qnorMix(u_error[2],ex))
     }else if(code==6){
	   a <- -10
	   b <- 5
	   unif <- runif(1,a,b) 
	   sd_term <- ((1/3)*((b-a)^2)*(1/rho^2-1))^.5
	   eta <- rnorm(1,0,sd_term)
	   f_of_unif <- (1/1)*2*unif + eta
	   errors[i,] <- cbind(f_of_unif,(unif+2.5))
	 }
  }
  return(errors)
}

ptm <- proc.time()
error <- draw.errors(distribution)
proc.time() - ptm

cor(error[,1],error[,2],method="spearman")
