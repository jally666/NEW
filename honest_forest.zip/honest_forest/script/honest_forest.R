library(randomForest)


obs <- 200

min_node_size <- 1


fit.honest.forest <- function(features,outcome){
obs <-length(outcome)
sample_size <- ceiling(obs*(2/3))
full_training_dataset   <- cbind(unname(outcome),unname(features))


#### Create tree list

tree_list <- list()

for(j in 1:500){
  # Take a sample without repalcement from P
  idx <- sample(1:obs, sample_size, replace=FALSE)
  W <- full_training_dataset[idx,]
  S <- W[1:ceiling(sample_size/2),]
  P <- W[(ceiling(sample_size/2)+1):sample_size,]
  size_S <- dim(S)[1]
  size_P <- dim(P)[1]
  
  for_saving_term_node <- matrix(NA,nrow=size_P,ncol=2)
  for_saving_term_node[,1] <- P[,1]
  
  # Get tree j
  RF <- randomForest(as.matrix(S[,-1]),as.matrix(S[,1]), importance=FALSE, replace=FALSE, ntree=1, sampsize=size_S)
  tree_list[[j]] <- getTree(RF, 1, labelVar=TRUE)
   
  # Find terminal node for each element in P
  for(i in 1:size_P){
    term_node <- 1
    status <- -3
    while(status != -1){
      status <- tree_list[[j]]$status[term_node]
      if(status != -1){ 
	  # if there is an error, it's here
	    var <- as.integer(tree_list[[j]]$'split var'[term_node])
        term_node<-ifelse(P[i,(var+1)] < tree_list[[j]]$'split point'[term_node],
	    tree_list[[j]]$'left daughter'[term_node],
	    tree_list[[j]]$'right daughter'[term_node])
      }
    }
    for_saving_term_node[i,2] <- term_node
  }
  
 # Get list of terminal nodes in tree j
  num_term_nodes <- sum(tree_list[[j]]$status == -1)
  list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
  #colnames(list_term_nodes) <- c("term_nose","size")
  
  place <- 1
  for(i in 1:dim(tree_list[[j]])[1]){
    if(tree_list[[j]]$status[i] == -1){
      list_term_nodes[place,1] <- i
	  list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
      place <- place + 1
    }
  }
  
  # Prune the tree if necessary
  while(min(list_term_nodes[,2])<min_node_size){
  #Prune
  for(i in 1:num_term_nodes){
    if(list_term_nodes[i,2]<min_node_size){
	  # Change node's status
	  tree_list[[j]]$status[list_term_nodes[i,1]] <- -99
	  # Change parent's status
	  if(sum(list_term_nodes[i,1] == tree_list[[j]]$'left daughter')){
	    parent <- match(list_term_nodes[i,1],tree_list[[j]]$'left daughter')
		tree_list[[j]]$'left daughter'[parent] <- 0
		tree_list[[j]]$'right daughter'[parent] <- 0
		tree_list[[j]]$status[parent] <- -1
	  }else{
	    parent <- match(list_term_nodes[i,1],tree_list[[j]]$'right daughter')
		tree_list[[j]]$'left daughter'[parent] <- 0
		tree_list[[j]]$'right daughter'[parent] <- 0
		tree_list[[j]]$status[parent] <- -1
	  }
	}
  }
  
  
  # Update terminal node for each element in P
  for(i in 1:size_P){
    term_node <- 1
    status <- -3
    while(status != -1){
      status <- tree_list[[j]]$status[term_node]
      if(status != -1){ # if there is an error, it's here
	    var <- as.integer(tree_list[[j]]$'split var'[term_node])
        term_node<-ifelse(P[i,(var+1)] < tree_list[[j]]$'split point'[term_node],
	    tree_list[[j]]$'left daughter'[term_node],
	    tree_list[[j]]$'right daughter'[term_node])
      }
    }
    for_saving_term_node[i,2] <- term_node
  }
  
  # Update list of terminal nodes
    num_term_nodes <- sum(tree_list[[j]]$status == -1)
    list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
    #colnames(list_term_nodes) <- c("term_nose","size")
    place <- 1
    for(i in 1:dim(tree_list[[j]])[1]){
      if(tree_list[[j]]$status[i] == -1){
        list_term_nodes[place,1] <- i
	    list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
        place <- place + 1
      }
    }
  }
  
  # Change predictions in tree j
  for(i in 1:dim(tree_list[[j]])[1]){
      if(tree_list[[j]]$status[i]== -1){
	     tree_list[[j]]$prediction[i]=mean(for_saving_term_node[which(for_saving_term_node[,2] == i),1]) 
      }
  }
}

return(tree_list)
}



predict.honest.forest <- function(tree_list,features,outcome){
# Prediction for full_training_dataset
full_training_dataset   <- cbind(unname(outcome),unname(features))

predictions <- matrix(NA,nrow=500,ncol=obs)
for(t in 1:500){
  
  for(i in 1:obs){
    term_node <- 1
    status <- -3
    while(status != -1){
      status <- tree_list[[t]]$status[term_node]
      if(status != -1){
	    var <- as.integer(tree_list[[t]]$'split var'[term_node])
        term_node<-ifelse(full_training_dataset[i,(var+1)] < tree_list[[t]]$'split point'[term_node],
	    tree_list[[t]]$'left daughter'[term_node],
	    tree_list[[t]]$'right daughter'[term_node])
      }
    }
    predictions[t,i] <- tree_list[[t]]$prediction[term_node]
  }
}

avg_predictions<-rep(NA,obs)
for(i in 1:obs){
  avg_predictions[i] <- mean(predictions[,i])
}
return(avg_predictions)
}


x <- rnorm(obs)
y <- rnorm(obs,sin(x),2)

HF <- fit.honest.forest(x,y)
pred_HF <- predict.honest.forest(HF,x,y)
RF<- randomForest(y~x)
pred_RF <- predict(RF,x)

mean((pred_HF-sin(x))^2)
mean((pred_RF-sin(x))^2)

mean((pred_HF-y)^2)
mean((pred_RF-y)^2)


