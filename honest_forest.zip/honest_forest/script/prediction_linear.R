
library(randomForest)
library(MASS) 
library(bbemkr) 
# Using nrr(x) to select bandwidth for kernel regression for propensity score
library(nor1mix)
library(compiler)

set.seed(1)

sim <- 1
obs <- 200

min_node_size <- 1

# Error terms. I think we're using 1, 3, and 4. Distribution 6 doesn't make sense for predictions.
distribution <- 1  # Use 1 for normal
                   #     2 for t-dist with 3 df
                   #     3 for bivariate chi squared with 1 degree of freedom
                   #     4 for bivariate beta distribution with a= ,b=
                   #     5 for bivariate mixture of normals
                   #     6 for "problematic" distribution

rho = .5  # use .5 and .9
sigma_sq = 1
varcovar <- matrix(c(sigma_sq,(sigma_sq^.5)*rho,(sigma_sq^.5)*rho, 1), nrow = 2, ncol = 2)
##############################################################################################
# Begining of function definitions
draw.errors <- function(code) {
  errors <- matrix(rep(NA,(obs*2)),nrow=obs,ncol=2)
  for(i in 1:obs){
     if(code==1){
        errors[i,] <- mvrnorm(1, rep(0,2), varcovar)
     }else if(code==2){
        errors[i,] <- rmvt(1, sigma=varcovar,df = 3) 
     }else if(code==3){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind((qchisq(u_error[1],df=1)-qchisq(.5,df=1)),(qchisq(u_error[2],df=1)-qchisq(.5,df=1)))
     }else if(code==4){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind((10*qbeta(u_error[1],.5,.5)-5),(10*qbeta(u_error[2],.5,.5)-5))
     }else if(code==5){
        norm_errors<- mvrnorm(1, rep(0,2), matrix(c(1,rho,rho, 1), nrow = 2, ncol = 2))
        u_error <- cbind(pnorm(norm_errors[1]),pnorm(norm_errors[2]))
        errors[i,] <- cbind(qnorMix(u_error[1],ex),qnorMix(u_error[2],ex))
     }else if(code==6){
	   a <- -10
	   b <- 5
	   unif <- runif(1,a,b) 
	   sd_term <- ((1/3)*((b-a)^2)*(1/rho^2-1))^.5
	   eta <- rnorm(1,0,sd_term)
	   f_of_unif <- (1/1)*2*unif + eta
	   errors[i,] <- cbind(f_of_unif,(unif+2.5))
	 }
  }
  return(errors)
}

calculate.MSE <- function(actual_values,predictions) {
  predictions[!is.finite(predictions)] <- NA
  per_sim_MSE <- array(data = NA, dim = sim)
  for(i in 1:sim){
    per_sim_MSE[i] <- mean((actual_values[,i] - predictions[,i])^2,na.rm=TRUE)
  }
  return(mean(per_sim_MSE))
}

fit.honest.forest <- function(features,outcome){
	obs <-length(outcome)
	sample_size <- ceiling(obs*(2/3))
	full_training_dataset   <- cbind(unname(outcome),unname(features))

	##two functions to get term_node
	find.term_node <- function(row_P, tree){
	pred <- predict(tree,row_P,nodes=TRUE)
	term_node <- attributes(pred)$nodes[1]
	return(term_node)
	}
	
	find.term_node2 <- function(row_P, tree){
	term_node <- 1
	status <- -3
	while(status != -1){
	  status <- tree$'status'[term_node]
	  if(status != -1){ 
	  # if there is an error, it's here
		var <- as.integer(tree$'split var'[term_node])
		term_node<-ifelse(row_P[(var+1)] < tree$'split point'[term_node],
		tree$'left daughter'[term_node],
		tree$'right daughter'[term_node])
	  }
	}
	return(term_node)
	}

	#### Create tree list

	tree_list <- list()

	for(j in 1:500){
	  # Take a sample without replacement from P
	  idx <- sample(1:obs, sample_size, replace=FALSE)
	  W <- full_training_dataset[idx,]
	  S <- W[1:ceiling(sample_size/2),]
	  P <- W[(ceiling(sample_size/2)+1):sample_size,]
	  size_S <- dim(S)[1]
	  size_P <- dim(P)[1]
	  
	  for_saving_term_node <- matrix(NA,nrow=size_P,ncol=2)
	  for_saving_term_node[,1] <- P[,1]
	  
	  # Get tree j
	  RF <- randomForest(as.matrix(S[,-1]),as.matrix(S[,1]), importance=FALSE, replace=FALSE, ntree=1, sampsize=size_S)
	  tree_list[[j]] <- getTree(RF, 1, labelVar=TRUE)
	  
	  # Find terminal node for each element in P
	  for_saving_term_node[,2] <- apply(data.frame(P[,-1]),1,tree=RF,find.term_node)
	  
	 # Get list of terminal nodes in tree j
	  num_term_nodes <- sum(tree_list[[j]]$status == -1)
	  list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
	  #colnames(list_term_nodes) <- c("term_nose","size")
	  
	  
	  place <- 1
	  for(i in 1:dim(tree_list[[j]])[1]){
		if(tree_list[[j]]$status[i] == -1){
		  list_term_nodes[place,1] <- i
		  list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
		  place <- place + 1
		}
	  }
	 
	  
	  # Prune the tree if necessary
	  while(min(list_term_nodes[,2])<min_node_size){
	  #Prune
	  for(i in 1:num_term_nodes){
		if(list_term_nodes[i,2]<min_node_size){
		  # Change node's status
		  tree_list[[j]]$status[list_term_nodes[i,1]] <- -99
		  # Change parent's status
		  if(sum(list_term_nodes[i,1] == tree_list[[j]]$'left daughter')){
			parent <- match(list_term_nodes[i,1],tree_list[[j]]$'left daughter')
			tree_list[[j]]$'left daughter'[parent] <- 0
			tree_list[[j]]$'right daughter'[parent] <- 0
			tree_list[[j]]$status[parent] <- -1
		  }else{
			parent <- match(list_term_nodes[i,1],tree_list[[j]]$'right daughter')
			tree_list[[j]]$'left daughter'[parent] <- 0
			tree_list[[j]]$'right daughter'[parent] <- 0
			tree_list[[j]]$status[parent] <- -1
		  }
		}
	  }
	  

	  # Update terminal node for each element in P
		for_saving_term_node[,2] <- apply(P,1,tree=tree_list[[j]],find.term_node2)
	  
	  # Update list of terminal nodes
		num_term_nodes <- sum(tree_list[[j]]$status == -1)
		list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
		#colnames(list_term_nodes) <- c("term_nose","size")
		place <- 1
		for(i in 1:dim(tree_list[[j]])[1]){
		  if(tree_list[[j]]$status[i] == -1){
			list_term_nodes[place,1] <- i
			list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
			place <- place + 1
		  }
		}
	  }
	  
	  # Change predictions in tree j
	  for(i in 1:dim(tree_list[[j]])[1]){
		  if(tree_list[[j]]$status[i]== -1){
			 tree_list[[j]]$prediction[i]=mean(for_saving_term_node[which(for_saving_term_node[,2] == i),1]) 
		  }
	  }
	}

	return(tree_list)
}

fit.honest.forest <- cmpfun(fit.honest.forest)


predict.honest.forest <- function(tree_list,features){
	# Prediction for full_training_dataset
	full_training_dataset   <-  data.frame(features)
	obs <-  dim(full_training_dataset)[1]
	predictions <- matrix(NA,nrow=500,ncol=obs)
	
	# this function is to predict every obs' one result
	pred.HF <- function(row_data,tree){
	term_node <- 1
	status <- -3
	while(status != -1){
	  status <- tree$status[term_node]
	  if(status != -1){
		var <- as.integer(tree$'split var'[term_node])
		term_node<-ifelse(row_data[(var)] < tree$'split point'[term_node],
		tree$'left daughter'[term_node],
		tree$'right daughter'[term_node])
	  }
	}
	return (tree$prediction[term_node])
	}
	
	pred.HF <- cmpfun(pred.HF)
	
	for(t in 1:500){

	  predictions[t,]=apply(full_training_dataset,1,tree=tree_list[[t]],pred.HF)
	  
	}

	avg_predictions<-apply(predictions,2,mean)

	return(avg_predictions)
} 

predict.honest.forest <- cmpfun(predict.honest.forest)

find_bandwidth_uncomp<-function(x,y){
  h <- seq(0.1,0.9,by=0.1)
  h_MSE <- rep(NA,nrow=length(h))
  for(j in 1:length(h)){
    MSE_LOO <- 0
    for(leave_out in 1:length(x)){
      x_LOO <- x[-leave_out]
      y_LOO <- y[-leave_out]
      dist  <- (x_LOO-x[leave_out]) / h[j]
      m     <- sum(dnorm(dist)*y_LOO) / sum(dnorm(dist))
      MSE_LOO <- MSE_LOO +(y[leave_out]-m)^2
    }
    h_MSE[j] <- MSE_LOO
  }
  return(h[which.min(h_MSE)])
}
find_bandwidth <- cmpfun(find_bandwidth_uncomp)
# multivariate Gaussian kernel
ker <- function(xx) {
  return(exp(-rowSums(xx^2)/2))
}
# End of function definitions
##############################################################################################


true_y <- matrix(NA,nrow=obs,ncol=sim)
HF_predictions <- matrix(NA,nrow=obs,ncol=sim)
HF_robinson_predictions <- matrix(NA,nrow=obs,ncol=sim)
OLS_predictions <- matrix(NA,nrow=obs,ncol=sim)
LIML_predictions <- matrix(NA,nrow=obs,ncol=sim)


ptm <- proc.time()

for(iteration in 1:sim){
# Data generating process
error <- draw.errors(distribution)

x     <- runif(obs,-5,5)
z     <- runif(obs,-5,5)
latent_y  <- x + error[,1]
selection <- 1*(x + z + error[,2] > 0)
y <- ifelse(selection==1, latent_y, NA)

x_out  <- runif(obs,-5,5)
z_out  <- runif(obs,-5,5)


# OLS
 OLS_coeff <-  as.matrix(unname(coef(lm(y~x))))
 OLS_predictions[,iteration] <- OLS_coeff[1]+OLS_coeff[2]*x_out


# LIML
  coeffs_selection <- unname(coef(glm(selection ~ x+z, family = binomial(link = "probit"))))
##
# For the inverse Mills, I bound the demoninator at pnorm(-30) to avoid dividing by zero
##
#  invMills <- ifelse(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection<  -30 ,
#    dnorm(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection)/pnorm(-30),
#    dnorm(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection)/pnorm(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection))
#  invMills_out <- ifelse(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection <  -30 ,
#    dnorm(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection)/pnorm(-30),
#    dnorm(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection)/pnorm(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection)  )
invMills <- dnorm(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection)/pnorm(cbind(rep(1,obs),cbind(x,z))%*%coeffs_selection)
invMills_out <-  dnorm(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection)/pnorm(cbind(rep(1,obs),cbind(x_out,z_out))%*%coeffs_selection)
  coeffs_outcome <- as.matrix(unname(coef(lm(y ~ cbind(x,invMills)))))
  LIML_predictions[,iteration] <- cbind(rep(1,obs),cbind(x_out,invMills_out))%*%coeffs_outcome  

# Get prob of selection
#HF_p_hat <- make.in.sample.predictions(cbind(x,z),selection)
#HF_p_hat_out <- make.out.sample.predictions(cbind(x,z),selection,cbind(x_out,z_out))

    for_p_hat <- fit.honest.forest(cbind(x,z),selection)
	HF_p_hat <- predict.honest.forest(for_p_hat,cbind(x,z))
	HF_p_hat_out <- predict.honest.forest(for_p_hat,cbind(x_out,z_out))
 
# Plain honest forest prediction
  data_for_HF_prediction <- as.data.frame(cbind(y,x,z))
  data_for_HF_prediction <- data_for_HF_prediction[complete.cases(data_for_HF_prediction[,1]),]
  #HF_predictions[,iteration] <-  make.out.sample.predictions(data_for_HF_prediction[,2:3],data_for_HF_prediction[,1],cbind(x_out,z_out))
     for_HF <- fit.honest.forest(data_for_HF_prediction[,2:3],data_for_HF_prediction[,1])
     HF_predictions[,iteration] <-  predict.honest.forest(for_HF,cbind(x_out,z_out))

# Create expected values of y,x1,x2 based on p_hat
full_data <-as.data.frame(cbind(y,x,HF_p_hat))
selected_sample <- full_data[complete.cases(full_data[,1]),]

#y_expect <- make.in.sample.predictions(selected_sample[,3],selected_sample[,1])
for_y_expect <- fit.honest.forest(selected_sample[,3],selected_sample[,1])
y_expect <- predict.honest.forest(for_y_expect,selected_sample[,3])
y_minus_expect <- selected_sample[,1]-y_expect

#x1_expect <- make.in.sample.predictions(selected_sample[,3],selected_sample[,2])
for_x1_expect <- fit.honest.forest(selected_sample[,3],selected_sample[,2])
x1_expect <- predict.honest.forest(for_x1_expect,selected_sample[,3])
x1_minus_expect <- selected_sample[,2]-x1_expect

  HF_coeff <- as.matrix(unname(coef(lm(y_minus_expect ~ 0 + x1_minus_expect ))))
  g_of_P <- selected_sample[,1] - HF_coeff*selected_sample[,2]
#  g_of_P_out_est <- make.out.sample.predictions(selected_sample[,3],g_of_P,HF_p_hat_out)
### Change to
    for_g <- fit.honest.forest(selected_sample[,3],g_of_P)
    g_of_P_out_est <-  predict.honest.forest(for_g,HF_p_hat_out)
	
	
  HF_robinson_predictions[,iteration] <- g_of_P_out_est + x_out%*%as.matrix(HF_coeff)
  
 
# Out-of-sample outcomes realized
  error <- draw.errors(distribution)
  latent_y     <- x_out + error[,1]
  selection <- 1*(x_out+z_out + error[,2] > 0)
  true_y[,iteration] <- ifelse(selection==1, latent_y, NA)

  
 if(iteration%%100==0){
   print(iteration)
   print(Sys.time())  
 }
}

proc.time() - ptm

calculate.MSE(true_y,HF_predictions)
calculate.MSE(true_y,OLS_predictions)
calculate.MSE(true_y,HF_robinson_predictions)
calculate.MSE(true_y,LIML_predictions)


