library(randomForest)
library(compiler)

setwd("P:/PCAOB Staff/Interns/zhangy1/R_project/honest_forest")
original.data<-read.csv("martins.csv",header=TRUE)

min_node_size<-1
fit.honest.forest <- function(features,outcome){
	obs <-length(outcome)
	sample_size <- ceiling(obs*(2/3))
	full_training_dataset   <- cbind(unname(outcome),unname(features))

	##two functions to get term_node
	find.term_node <- function(row_P, tree){
	pred <- predict(tree,row_P,nodes=TRUE)
	term_node <- attributes(pred)$nodes[1]
	return(term_node)
	}
	
	find.term_node2 <- function(row_P, tree){
	term_node <- 1
	status <- -3
	while(status != -1){
	  status <- tree$'status'[term_node]
	  if(status != -1){ 
	  # if there is an error, it's here
		var <- as.integer(tree$'split var'[term_node])
		term_node<-ifelse(row_P[(var+1)] < tree$'split point'[term_node],
		tree$'left daughter'[term_node],
		tree$'right daughter'[term_node])
	  }
	}
	return(term_node)
	}

	#### Create tree list

	tree_list <- list()

	for(j in 1:500){
	  # Take a sample without replacement from P
	  idx <- sample(1:obs, sample_size, replace=FALSE)
	  W <- full_training_dataset[idx,]
	  S <- W[1:ceiling(sample_size/2),]
	  P <- W[(ceiling(sample_size/2)+1):sample_size,]
	  size_S <- dim(S)[1]
	  size_P <- dim(P)[1]
	  
	  for_saving_term_node <- matrix(NA,nrow=size_P,ncol=2)
	  for_saving_term_node[,1] <- P[,1]
	  
	  # Get tree j
	  RF <- randomForest(as.matrix(S[,-1]),as.matrix(S[,1]), importance=FALSE, replace=FALSE, ntree=1, sampsize=size_S)
	  tree_list[[j]] <- getTree(RF, 1, labelVar=TRUE)
	  
	  # Find terminal node for each element in P
	  for_saving_term_node[,2] <- apply(data.frame(P[,-1]),1,tree=RF,find.term_node)
	  
	 # Get list of terminal nodes in tree j
	  num_term_nodes <- sum(tree_list[[j]]$status == -1)
	  list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
	  #colnames(list_term_nodes) <- c("term_nose","size")
	  
	  
	  place <- 1
	  for(i in 1:dim(tree_list[[j]])[1]){
		if(tree_list[[j]]$status[i] == -1){
		  list_term_nodes[place,1] <- i
		  list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
		  place <- place + 1
		}
	  }
	 
	  
	  # Prune the tree if necessary
	  while(min(list_term_nodes[,2])<min_node_size){
	  #Prune
	  for(i in 1:num_term_nodes){
		if(list_term_nodes[i,2]<min_node_size){
		  # Change node's status
		  tree_list[[j]]$status[list_term_nodes[i,1]] <- -99
		  # Change parent's status
		  if(sum(list_term_nodes[i,1] == tree_list[[j]]$'left daughter')){
			parent <- match(list_term_nodes[i,1],tree_list[[j]]$'left daughter')
			tree_list[[j]]$'left daughter'[parent] <- 0
			tree_list[[j]]$'right daughter'[parent] <- 0
			tree_list[[j]]$status[parent] <- -1
		  }else{
			parent <- match(list_term_nodes[i,1],tree_list[[j]]$'right daughter')
			tree_list[[j]]$'left daughter'[parent] <- 0
			tree_list[[j]]$'right daughter'[parent] <- 0
			tree_list[[j]]$status[parent] <- -1
		  }
		}
	  }
	  

	  # Update terminal node for each element in P
		for_saving_term_node[,2] <- apply(P,1,tree=tree_list[[j]],find.term_node2)
	  
	  # Update list of terminal nodes
		num_term_nodes <- sum(tree_list[[j]]$status == -1)
		list_term_nodes <- matrix(NA,ncol=2,nrow=num_term_nodes)
		#colnames(list_term_nodes) <- c("term_nose","size")
		place <- 1
		for(i in 1:dim(tree_list[[j]])[1]){
		  if(tree_list[[j]]$status[i] == -1){
			list_term_nodes[place,1] <- i
			list_term_nodes[place,2] <- sum(for_saving_term_node[,2]==list_term_nodes[place,1])
			place <- place + 1
		  }
		}
	  }
	  
	  # Change predictions in tree j
	  for(i in 1:dim(tree_list[[j]])[1]){
		  if(tree_list[[j]]$status[i]== -1){
			 tree_list[[j]]$prediction[i]=mean(for_saving_term_node[which(for_saving_term_node[,2] == i),1]) 
		  }
	  }
	}

	return(tree_list)
}

fit.honest.forest <- cmpfun(fit.honest.forest)


predict.honest.forest <- function(tree_list,features){
	# Prediction for full_training_dataset
	full_training_dataset   <-  data.frame(features)
	obs <-  dim(full_training_dataset)[1]
	predictions <- matrix(NA,nrow=500,ncol=obs)
	
	# this function is to predict every obs' one result
	pred.HF <- function(row_data,tree){
	term_node <- 1
	status <- -3
	while(status != -1){
	  status <- tree$status[term_node]
	  if(status != -1){
		var <- as.integer(tree$'split var'[term_node])
		term_node<-ifelse(row_data[(var)] < tree$'split point'[term_node],
		tree$'left daughter'[term_node],
		tree$'right daughter'[term_node])
	  }
	}
	return (tree$prediction[term_node])
	}
	
	pred.HF <- cmpfun(pred.HF)
	
	for(t in 1:500){

	  predictions[t,]=apply(full_training_dataset,1,tree=tree_list[[t]],pred.HF)
	  
	}

	avg_predictions<-apply(predictions,2,mean)

	return(avg_predictions)
} 

predict.honest.forest <- cmpfun(predict.honest.forest)



get.LIML.estimates<-function(data){
####################################################################################################
####################################################################################################
#   This part performs Heckman's LIML
####################################################################################################
  obs <- length(data$observed )
  sel_sq_vars <- as.matrix(data[,c("children", "ychildren", "lhw", "education", "age",  "agesq")])
 
  coeffs_selection <- unname(coef(glm(data$observed ~ sel_sq_vars, data=data, family = binomial(link = "probit"))))
  invMills <- dnorm(cbind(rep(1,obs),sel_sq_vars)%*%coeffs_selection)/pnorm(cbind(rep(1,obs),sel_sq_vars)%*%coeffs_selection)
  
  
  data.Heck<-data.frame(data,invMills)
  observed.data <- data.Heck[which(data.Heck[,"observed"]==1),]
  outcome_eq_vars <- observed.data[,c("education" ,"pexp","pexpsq", "pexp_children", "pexpsq_children")]
  coeffs_outcome <- unname(coef(lm(observed.data$lwage ~ as.matrix(cbind(outcome_eq_vars,observed.data$invMills)))))
  
  Heck_answer <- coeffs_outcome[2:6]
  return(Heck_answer)
}
get.CS.estimates<-function(data){
####################################################################################################
####################################################################################################
#   This part performs Robinson estiamtino with random forests
####################################################################################################
## Find Pr(observed==1)
for_p <- fit.honest.forest(data[,c("children", "ychildren", "lhw", "education", "age",  "agesq")],data[,"observed"])
p_hat <- predict.honest.forest(for_p,data[,c("children", "ychildren", "lhw", "education", "age",  "agesq")])


data.RF<-data.frame(data,p_hat)
observed.data <- data.RF[which(data.RF[,"observed"]==1),]

##  education pexp pexpsq pexp_children pexpsq_children
varlist=c("lwage", "education" ,"pexp","pexpsq", "pexp_children", "pexpsq_children")

for (var in varlist){
  assign(paste("for",var,sep="_"), fit.honest.forest(observed.data$"p_hat",observed.data[,var]))
  assign(paste(var,"hat",sep="_"), predict.honest.forest(get(paste("for",var,sep="_")),observed.data$"p_hat"))
  assign(paste(var,"mins_exp",sep="_"),observed.data[,var] - get(paste(var,"hat",sep="_")))
}

CS_answer<-coef(lm(lwage_mins_exp ~ 0 + education_mins_exp + pexp_mins_exp + pexpsq_mins_exp +  pexp_children_mins_exp +  pexpsq_children_mins_exp))

return(CS_answer)
}

nboot <- 100
n<-length(original.data$lwage)
 # Bootstrap
 boot.Heck.answer <- boot.CS.answer <- matrix(NA,nrow=5,ncol=nboot)
 
 
 
    for(j in 1:nboot){
	  if(j%%10==0){
      print(j)
      print(Sys.time())  
      }    
      idx <- sample(1:n, n, replace=TRUE)
      boot.Heck.answer[,j] <- as.matrix(get.LIML.estimates(original.data[idx,]))
      boot.CS.answer[,j]   <- as.matrix(get.CS.estimates(original.data[idx,]))
    }

write.csv(boot.Heck.answer, "P:/PCAOB Staff/Interns/zhangy1/R_project/honest_forest/result_HECK1.csv")
write.csv(boot.CS.answer, "P:/PCAOB Staff/Interns/zhangy1/R_project/honest_forest/result_CS1.csv")
