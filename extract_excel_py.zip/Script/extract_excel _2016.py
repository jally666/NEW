#--------------------------------#
# Author: Yichen Zhang
# Date: 8/10/2017

#This code is to extract 2016 engagement data of 
#Sheet("1.Issuers and Engagement Data"): CIK, firm, issuer name,
#Sheet("9. Information Systems"): new auditing tools
#--------------------------------#
#import
import os
import xlrd
import xlwt
import pandas as pd
from pandas import ExcelWriter
import fnmatch
import numpy
import re


#set original df

results_df=pd.DataFrame()
wrong_files=[]

path="P:\\PCAOB Staff\\Interns\\zhangy1\\Engagement Profile Extraction_ Saad\\2016"
# recursively go through all Excel files in folder and its subfolders
files_list = [os.path.join(dirpath, f) for dirpath, dirnames, fi in os.walk(path) for f in fnmatch.filter(fi, '*.*xls*')] 

#here is the loop for each file
for xlsfile in files_list:

	tool_leverage_list=[]
	supported_list=[]
	office_list=[]

	companyname=""
	cik=""
	auditfirm=""
	usetechnology=""
	technologyname=""
	index_Infsys=""
	technum=""
	note=""

	try:
		book = xlrd.open_workbook(xlsfile)
		sheet_names = book.sheet_names()

		#Referred Work
		word = ['Referred',"Appendix"]
		note=""
		for j in word:
			if j in xlsfile:
				note = j		


		## find if Information System is "9."
		IS_num1=numpy.nan
		IS_num2=numpy.nan
		for i in range(0, len(sheet_names)):
			if re.findall("9. Information Systems",sheet_names[i]):
				IS_num1=i
			if re.findall("Information Systems",sheet_names[i]):
				IS_num2=i

		if IS_num1==IS_num2:
			index_infsys="Y"
		else:
			index_infsys="N"


		#find "Issuer and Engagement Data"'s index
		iss_Eng_num=numpy.nan
		for i in range(0, len(sheet_names)):
			if re.findall("Engagement Data",sheet_names[i]):
				iss_Eng_num=i	

		sheet1 = book.sheet_by_index(int(iss_Eng_num))
		sheet9 = book.sheet_by_index(int(IS_num2))
		
		#loop for isseur name, cik, audit firm				
		for c in range (sheet1.ncols):
			for r in range(sheet1.nrows):
				cell = sheet1.cell(r,c)
				if (type(cell.value) != int )& (type(cell.value) !=float):
					if re.findall("Issuer name",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Issuer name':
						companyname = sheet1.cell(r,c+1).value.encode('ascii','ignore')
						continue
					if re.findall("Primary Issuer Central Index Key",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Primary Issuer Central Index Key (CIK)':
						if type(sheet1.cell(r,c+1).value)==float:
							cik = str(int(sheet1.cell(r,c+1).value))
						else:
							cik = str(sheet1.cell(r,c+1).value)
					
						continue
					if re.findall("Audit firm",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Audit firm':
						auditfirm = sheet1.cell(r,c+1).value.encode('ascii','ignore')

						
		#loop for technology
		for c in range (sheet9.ncols):
			for r in range(sheet9.nrows):
					cell = sheet9.cell(r,c)
					if (type(cell.value) != int )&( type(cell.value) !=float):
						if re.findall("Did the engagement team use software audit tools",cell.value.encode('ascii', 'ignore')):
							technum=r+1
							usetechnology = str(sheet9.cell(r,c+1).value).upper()
			
						if re.findall("Software Audit Tools", cell.value.encode('ascii', 'ignore')):
							toolrow=r+2
							toolcol=c					
							##loop for sheet9 Software Audit Tools
							while True:
								if (sheet9.cell(toolrow,toolcol).value.encode('ascii','ignore').strip()=="") | (sheet9.cell(toolrow,toolcol).value.encode('ascii','ignore').strip()=="N/A"):
									break
								tool_leverage=sheet9.cell(toolrow,toolcol).value.encode('ascii','ignore')
								tool_leverage_list.append(tool_leverage)
								supported=sheet9.cell(toolrow,toolcol+1).value.encode('ascii','ignore')
								supported_list.append(supported)
								office=sheet9.cell(toolrow,toolcol+2).value.encode('ascii','ignore')
								office_list.append(office)
								toolrow=toolrow+1

								
		#to check if it's empty list						
		if len(tool_leverage_list)==0:
				tool_leverage_list.append(" ")
				supported_list.append(" ")
				office_list.append(" ")
			
		## transfer lists to dataframe		
		columns={"CompanyName":companyname,"CIK":cik,"AuditFirm":auditfirm,"9. Information System":index_infsys}
		columns.update({"Techrow":technum,"UseTech":usetechnology,"Source":xlsfile,"Note":note,"Tool_leverage":tool_leverage_list})
		columns.update({"Support":supported_list,"Approved":office_list})

		df=pd.DataFrame(columns)
		results_df=results_df.append(df)
		results_df.reset_index(drop=True)


		results_df["AuditFirm"]=results_df["AuditFirm"].str.upper()
		results_df.loc[results_df['AuditFirm'].str.contains('DELOITTE', case=False), 'AuditFirm'] = 'DT'
		results_df.loc[results_df['AuditFirm'].str.contains('BDO', case=False), 'AuditFirm'] = 'BDO'
		results_df.loc[results_df['AuditFirm'].str.contains('GRANT THORNTON', case=False), 'AuditFirm'] = 'GT'
		results_df.loc[results_df['AuditFirm'].str.contains('ERNST', case=False), 'AuditFirm'] = 'EY'
		results_df.loc[results_df['AuditFirm'].str.contains('PRICEWATERHOUSECOOPERS', case=False), 'AuditFirm'] = 'PWC'
		results_df.loc[results_df['AuditFirm'].str.contains('KPMG', case=False), 'AuditFirm'] = 'KPMG'
		results_df.loc[results_df['AuditFirm'].str.contains('CROWE', case=False), 'AuditFirm'] = 'CROWE HORWATH'
		results_df.loc[results_df['AuditFirm'].str.contains('MCGLADREY', case=False), 'AuditFirm'] = 'MCGLADREY'

		results_df["UseTech"]=results_df["UseTech"].str.upper()
		results_df.loc[results_df['UseTech'].str.contains('YES', case=False), 'UseTech'] = 'YES'
		results_df.loc[results_df['UseTech'].str.contains('NO', case=False), 'UseTech'] = 'NO'
				
	except:
		print xlsfile
		wrong_files.append(xlsfile)
		pass
						

wrong_df=pd.DataFrame(wrong_files)							
							
#save in excel
results="P:/PCAOB Staff/Interns/zhangy1/Engagement Profile Extraction_ Saad/test_2016.csv"
#writer = ExcelWriter(results)
results_df.to_csv(results, index=False)
#results_df.to_excel(writer,'Python Extraction',index=False)
#wrong_df.to_excel(writer,"problematic files",index=False)
#writer.save()



