#--------------------------------#
# Author: Yichen Zhang
# Date: 8/10/2017

#This code is to extract 2013 engagement data of 
#Sheet("1.Issuers and Engagement Data"): CIK, firm, issuer name,
#Sheet("9. Information Systems"): whether use other auditing technology

#--------------------------------#

#import
import os
import xlrd
import xlwt
import pandas as pd
from pandas import ExcelWriter
import fnmatch
import numpy
import re


#set original df

results_df=pd.DataFrame()
wrong_files=[]

path='P:\\Data\\PCAOBdata\\data\\engagement_profiles\\2013'
# recursively go through all Excel files in folder and its subfolders
files_list = [os.path.join(dirpath, f) for dirpath, dirnames, fi in os.walk(path) for f in fnmatch.filter(fi, '*.*xls*')] 
for xlsfile in files_list:
	companyname_list=[]
	cik_list=[]
	auditfirm_list=[]
	usetechnology_list=[]
	technologyname_list=[]
	index_Infsys_list=[]
	technum_list=[]
	note_list=[]
	try: 
		book = xlrd.open_workbook(xlsfile)
		sheet_names = book.sheet_names()
		
		#Referred Work
		word = ['Referred',"Appendix"]
		note=""
		for j in word:
			if j in xlsfile:
				note = j		
		note_list.append(note)	
		
		## find if Information System is "9."
		IS_num1=numpy.nan
		IS_num2=numpy.nan
		for i in range(0, len(sheet_names)):
			if re.findall("9. Information Systems",sheet_names[i]):
				IS_num1=i
			if re.findall("Information Systems",sheet_names[i]):
				IS_num2=i
		
		if IS_num1==IS_num2:
			index_infsys="Y"
		else:
			index_infsys="N"
		index_Infsys_list.append(index_infsys)
		
		#find "Issuer and Engagement Data"'s index
		iss_Eng_num=numpy.nan
		for i in range(0, len(sheet_names)):
			if re.findall("Engagement Data",sheet_names[i]):
				iss_Eng_num=i	
	
		sheet1 = book.sheet_by_index(int(iss_Eng_num))
		sheet9 = book.sheet_by_index(int(IS_num2))

		#loop for isseur name, cik, audit firm				
		for c in range (sheet1.ncols):
			for r in range(sheet1.nrows):
				cell = sheet1.cell(r,c)
				if (type(cell.value) != int )& (type(cell.value) !=float):
					if re.findall("Issuer name",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Issuer name':
						companyname = sheet1.cell(r,c+1).value.encode('ascii','ignore')
						companyname_list.append(companyname)
						continue
					if re.findall("Primary Issuer Central Index Key",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Primary Issuer Central Index Key (CIK)':
						if type(sheet1.cell(r,c+1).value)==float:
							cik = str(int(sheet1.cell(r,c+1).value))
						else:
							cik = str(sheet1.cell(r,c+1).value)
						cik_list.append(cik)
						continue
					if re.findall("Audit firm",cell.value.encode('ascii','ignore')):
					#if cell.value == u'Audit firm':
						auditfirm = sheet1.cell(r,c+1).value.encode('ascii','ignore')
						auditfirm_list.append(auditfirm)
						
		#loop for technology
		for c in range (sheet9.ncols):
			for r in range(sheet9.nrows):
					cell = sheet9.cell(r,c)
					if (type(cell.value) != int )&( type(cell.value) !=float):
						if re.findall("Did the engagement team use any tools to perform its audit procedures",cell.value.encode('ascii', 'ignore')):
							technum=r+1
							technum_list.append(technum)
							usetechnology = str(sheet9.cell(r,c+1).value).upper()
							usetechnology_list.append(usetechnology)
							usetech=""
							if re.findall("YES(.*)",usetechnology):
								usetech=re.search("YES(.*)",usetechnology).group(1)
							technologyname = sheet9.cell(r+1,c+1).value.encode('ascii','ignore').strip()
							if (technologyname =="" )| (technologyname=="N/A"):
								technologyname = usetech[1:].strip()
							technologyname_list.append(technologyname)
		
		## transfer lists to dataframe		
		columns={"CompanyName":companyname_list,"CIK":cik_list,"AuditFirm":auditfirm_list,"9. Information System":index_Infsys_list,"Techrow":technum_list,"UseTech":usetechnology_list,"TechName":technologyname_list,"Source":xlsfile,"Note":note_list}
		for key, value in columns.items():
			if len(value)==0:
				value.append(" ")
				columns[key] = value
		df=pd.DataFrame(columns, index=[0])
		results_df=results_df.append(df)
		
		# data cleaning
		results_df["AuditFirm"]=results_df["AuditFirm"].str.upper()
		results_df.loc[results_df['AuditFirm'].str.contains('DELOITTE', case=False), 'AuditFirm'] = 'DT'
		results_df.loc[results_df['AuditFirm'].str.contains('BDO', case=False), 'AuditFirm'] = 'BDO'
		results_df.loc[results_df['AuditFirm'].str.contains('GRANT THORNTON', case=False), 'AuditFirm'] = 'GT'
		results_df.loc[results_df['AuditFirm'].str.contains('ERNST', case=False), 'AuditFirm'] = 'EY'
		results_df.loc[results_df['AuditFirm'].str.contains('PRICEWATERHOUSECOOPERS', case=False), 'AuditFirm'] = 'PWC'
		results_df.loc[results_df['AuditFirm'].str.contains('KPMG', case=False), 'AuditFirm'] = 'KPMG'
		results_df.loc[results_df['AuditFirm'].str.contains('CROWE', case=False), 'AuditFirm'] = 'CROWE HORWATH'
		results_df.loc[results_df['AuditFirm'].str.contains('MCGLADREY', case=False), 'AuditFirm'] = 'MCGLADREY'
		
		results_df["UseTech"]=results_df["UseTech"].str.upper()
		results_df.loc[results_df['UseTech'].str.contains('YES', case=False), 'UseTech'] = 'YES'
		results_df.loc[results_df['UseTech'].str.contains('NO', case=False), 'UseTech'] = 'NO'
		
	except:
		print xlsfile
		wrong_files.append(xlsfile)
		pass
							

wrong_df=pd.DataFrame(wrong_files)							
							
#save in excel
results="P:/PCAOB Staff/Interns/zhangy1/Engagement Profile Extraction_ Saad/test_2015.xlsx"
writer = ExcelWriter(results)
results_df.to_excel(writer,'Python Extraction',index=False)
wrong_df.to_excel(writer,"problematic files",index=False)
writer.save()



