import unittest
import time
import re
import sys
import os

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from selenium.webdriver.chrome.chrome_binary import ChromeBinary


binary = FirefoxBinary('C:\\Program Files\\Mozilla Firefox\\firefox.exe')
caps = DesiredCapabilities().FIREFOX
caps["marionette"] = True
driver = webdriver.Firefox(capabilities=caps, firefox_binary=binary, executable_path="C:\\Utility\\BrowserDrivers\\geckodriver.exe")
driver.get('https://stackoverflow.com')
driver=webdriver.Chrome(executable_path="C:\\Python27\\chromedriver.exe")

#Selenium requires a driver to interface with the chosen browser. Firefox, for example, requires geckodriver, 
#which needs to be installed before the below examples can be run. Make sure it’s in your PATH, e. g., place it in /usr/bin or /usr/local/bin.
driver = webdriver.Firefox()
driver.get("http://www.twitter.com")

driver.get(url)